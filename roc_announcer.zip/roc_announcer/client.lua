local manhuntActive = false

RegisterNetEvent("roc:announce")
AddEventHandler("roc:announce", function(msg)
    SendNUIMessage({
        type = "announcement",
        text = msg
    })
end)

RegisterNetEvent("roc:startManhunt")
AddEventHandler("roc:startManhunt", function(name, reason)
    manhuntActive = true

    SendNUIMessage({
        type = "manhunt",
        suspect = name,
        reason = reason
    })

    CreateThread(function()
        while manhuntActive do
            SetTimecycleModifier("REDMIST_blend")
            Wait(350)
            ClearTimecycleModifier()
            Wait(350)
        end
    end)
end)

RegisterNetEvent("roc:endManhunt")
AddEventHandler("roc:endManhunt", function()
    manhuntActive = false
    SendNUIMessage({ type = "clear" })
    ClearTimecycleModifier()
end)
