window.addEventListener("message", function(event) {
    let data = event.data;
    let box = document.getElementById("announcement");

    if (data.type === "announcement") {
        box.className = "";
        box.innerHTML = "📢 ANNOUNCEMENT: " + data.text;
        box.style.display = "block";

        setTimeout(() => {
            box.style.display = "none";
        }, 8000);
    }

    if (data.type === "manhunt") {
        box.className = "manhunt";
        box.innerHTML = `
            🚨 MANHUNT ACTIVE 🚨<br><br>
            Suspect: ${data.suspect}<br>
            Charges: ${data.reason}
        `;
        box.style.display = "block";
    }

    if (data.type === "clear") {
        box.style.display = "none";
    }
});
