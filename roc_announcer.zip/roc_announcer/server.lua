RegisterCommand("announce", function(source, args)
    local msg = table.concat(args, " ")
    if msg == "" then return end
    TriggerClientEvent("roc:announce", -1, msg)
end, true)

RegisterCommand("manhunt", function(source, args)
    if #args < 2 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"SYSTEM", "Usage: /manhunt [Name/ID] [Reason]"}
        })
        return
    end

    local targetInput = args[1]
    table.remove(args, 1)
    local reason = table.concat(args, " ")
    local suspectName = targetInput

    if tonumber(targetInput) then
        local target = GetPlayerName(tonumber(targetInput))
        if target then
            suspectName = target
        end
    end

    TriggerClientEvent("roc:startManhunt", -1, suspectName, reason)
end, true)

RegisterCommand("endmanhunt", function(source)
    TriggerClientEvent("roc:endManhunt", -1)
end, true)
